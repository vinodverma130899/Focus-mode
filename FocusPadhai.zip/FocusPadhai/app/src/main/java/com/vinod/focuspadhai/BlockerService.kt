package com.vinod.focuspadhai

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager
import android.widget.Toast

class BlockerService : AccessibilityService() {
    private var lastBlock = 0L

    override fun onAccessibilityEvent(ev: AccessibilityEvent?) {
        if (ev?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        if (!Store.isOn(this)) return
        val pkg = ev.packageName?.toString() ?: return
        if (pkg in Store.allowed(this) || pkg in alwaysAllowed()) return
        val now = System.currentTimeMillis()
        if (now - lastBlock < 800) return
        lastBlock = now
        performGlobalAction(GLOBAL_ACTION_HOME)
        Toast.makeText(this, "Focus mode ON hai. Padhai karo!", Toast.LENGTH_SHORT).show()
    }

    // Home screen, keyboard, call screen aur system UI kabhi block nahi hote
    private fun alwaysAllowed(): Set<String> {
        val s = mutableSetOf(
            packageName, "android", "com.android.systemui", "com.android.dialer",
            "com.google.android.dialer", "com.android.incallui"
        )
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        packageManager.queryIntentActivities(home, 0).forEach { s.add(it.activityInfo.packageName) }
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .enabledInputMethodList.forEach { s.add(it.packageName) }
        return s
    }

    override fun onInterrupt() {}
}
