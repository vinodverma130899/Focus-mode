package com.vinod.focuspadhai

import android.content.Context
import java.util.Calendar

object Store {
    private fun p(c: Context) = c.getSharedPreferences("focus", Context.MODE_PRIVATE)

    fun startTime(c: Context) = p(c).getLong("start", 0L)
    fun isOn(c: Context) = startTime(c) > 0L
    fun start(c: Context) = p(c).edit().putLong("start", System.currentTimeMillis()).apply()

    fun stop(c: Context) {
        val s = startTime(c)
        if (s == 0L) return
        val e = System.currentTimeMillis()
        val list = p(c).getStringSet("sessions", emptySet())!!.toMutableSet()
        if (e - s > 5000) list.add("$s:$e")
        p(c).edit().putStringSet("sessions", list).putLong("start", 0L).apply()
    }

    fun allowed(c: Context): Set<String> = p(c).getStringSet("allowed", emptySet())!!.toSet()

    fun setAllowed(c: Context, pkg: String, yes: Boolean) {
        val s = allowed(c).toMutableSet()
        if (yes) s.add(pkg) else s.remove(pkg)
        p(c).edit().putStringSet("allowed", s).apply()
    }

    fun todayMillis(c: Context): Long {
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        val mid = cal.timeInMillis
        val now = System.currentTimeMillis()
        var total = 0L
        p(c).getStringSet("sessions", emptySet())!!.forEach {
            val (s, e) = it.split(":").map { x -> x.toLong() }
            total += maxOf(0L, e - maxOf(s, mid))
        }
        if (isOn(c)) total += maxOf(0L, now - maxOf(startTime(c), mid))
        return total
    }
}
