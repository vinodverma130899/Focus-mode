package com.vinod.focuspadhai

import android.app.Activity
import android.app.NotificationManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var clock: TextView
    private lateinit var status: TextView
    private lateinit var today: TextView
    private lateinit var toggle: Button
    private lateinit var dndBtn: Button

    private val tick = object : Runnable {
        override fun run() { refresh(); h.postDelayed(this, 1000) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val dp = resources.displayMetrics.density
        val pad = (16 * dp).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad) }

        clock = TextView(this).apply { textSize = 52f; gravity = Gravity.CENTER; typeface = Typeface.SERIF }
        status = TextView(this).apply { gravity = Gravity.CENTER; textSize = 15f }
        today = TextView(this).apply { gravity = Gravity.CENTER; textSize = 16f; setPadding(0, pad / 2, 0, pad / 2) }
        toggle = Button(this).apply { textSize = 18f; setOnClickListener { onToggle() } }
        dndBtn = Button(this).apply {
            text = "Do Not Disturb ki permission do (optional)"
            setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }
        }
        root.addView(clock); root.addView(status); root.addView(today); root.addView(toggle); root.addView(dndBtn)
        root.addView(TextView(this).apply {
            text = "Focus mode mein ye apps chalengi:"; textSize = 16f
            setTypeface(null, Typeface.BOLD); setPadding(0, pad, 0, 0)
        })

        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val launch = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = packageManager.queryIntentActivities(launch, 0)
            .filter { it.activityInfo.packageName != packageName }
            .map { it.activityInfo.packageName to it.loadLabel(packageManager).toString() }
            .distinctBy { it.first }.sortedBy { it.second.lowercase() }
        val allowed = Store.allowed(this)
        apps.forEach { (pkg, label) ->
            list.addView(CheckBox(this).apply {
                text = label; isChecked = pkg in allowed
                setOnCheckedChangeListener { _, yes -> Store.setAllowed(this@MainActivity, pkg, yes) }
            })
        }
        root.addView(list)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }

    private fun serviceEnabled(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val cn = ComponentName(this, BlockerService::class.java)
        return enabled.contains(cn.flattenToString()) || enabled.contains(cn.flattenToShortString())
    }

    private fun setDnd(on: Boolean) {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (nm.isNotificationPolicyAccessGranted) {
            nm.setInterruptionFilter(
                if (on) NotificationManager.INTERRUPTION_FILTER_PRIORITY
                else NotificationManager.INTERRUPTION_FILTER_ALL
            )
        }
    }

    private fun onToggle() {
        if (Store.isOn(this)) {
            Store.stop(this); setDnd(false)
        } else if (!serviceEnabled()) {
            Toast.makeText(this, "Pehle Accessibility mein 'Focus Padhai' ON karo", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        } else {
            Store.start(this); setDnd(true)
        }
        refresh()
    }

    private fun fmt(ms: Long): String {
        val s = ms / 1000
        return "%02d:%02d:%02d".format(s / 3600, s % 3600 / 60, s % 60)
    }

    private fun refresh() {
        val on = Store.isOn(this)
        clock.text = if (on) fmt(System.currentTimeMillis() - Store.startTime(this)) else "00:00:00"
        status.text = if (on) "Padhai chal rahi hai" else "Focus mode band hai"
        toggle.text = if (on) "Focus mode band karo" else "Focus mode ON karo"
        val m = Store.todayMillis(this) / 60000
        today.text = "Aaj ki padhai: ${m / 60}h ${m % 60}m"
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        dndBtn.visibility = if (nm.isNotificationPolicyAccessGranted) android.view.View.GONE else android.view.View.VISIBLE
    }
}
